# Keycloak JS

The documentation can be found in the [Keycloak documentation](https://www.keycloak.org/docs/latest/securing_apps/index.html#_javascript_adapter).
