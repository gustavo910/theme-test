Maintainers
===========

* [Stian Thorgersen](https://github.com/stianst) (project lead)
* [Bruno Oliveira da Silva](https://github.com/abstractj)
* [Hynek Mlnařík](https://github.com/hmlnarik)
* [Marek Posolda](https://github.com/mposolda)
* [Michal Hajas](https://github.com/mhajas)
* [Pavel Drozd](https://github.com/pdrozd)
* [Pedro Igor](https://github.com/pedroigor)
* [Stan Silvert](https://github.com/ssilvert)
* [Takashi Norimatsu](https://github.com/tnorimat)
* [Thomas Darimont](https://github.com/thomasdarimont)
* [Václav Muzikář](https://github.com/vmuzikar)
